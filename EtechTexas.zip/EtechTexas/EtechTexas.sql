CREATE DATABASE [Learn]
Go


USE [Learn]
GO

/****** Object:  Table [dbo].[EtechTexasProduct]    Script Date: 8/19/2019 12:15:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[EtechTexasProduct](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[ItemName] [varchar](50) NOT NULL,
	[Price] [int] NOT NULL,
	[ProductImage] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[EtechTexasProduct] ADD  DEFAULT ((0)) FOR [Price]
GO


GO


INSERT INTO [dbo].[EtechTexasProduct]
           ([ItemName]
           ,[Price]
           ,[ProductImage])
     VALUES
           ('LS2727 Avatar Day and Date Functioning Crocodile S'
           ,456
           ,'watch.jpeg')
GO

INSERT INTO [dbo].[EtechTexasProduct]
           ([ItemName]
           ,[Price]
           ,[ProductImage])
     VALUES
           ('Vivo V3 (Gold, 32 GB)  (3 GB RAM)'
           ,8236
           ,'Mobile.jpeg')
GO

INSERT INTO [dbo].[EtechTexasProduct]
           ([ItemName]
           ,[Price]
           ,[ProductImage])
     VALUES
           ('Royaldeals Rd-Lantern 5800 Emergency Light'
           ,505
           ,'electrical gudget.jpeg')
GO


/****** Object:  StoredProcedure [dbo].[AddProduct]    Script Date: 8/19/2019 12:15:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

GO

Create Procedure [dbo].[AddProduct]
(    
   @ItemName varchar (50),    
   @Price varchar (50),    
   @ProductImage VARCHAR(max) 
)    
as    
begin    
   Insert into EtechTexasProduct values(@ItemName,@Price,
   Cast(@ProductImage As varbinary(max)))    
End 
GO

GO
/****** Object:  StoredProcedure [dbo].[GetProduct]    Script Date: 8/19/2019 12:15:55 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create Procedure [dbo].[GetProduct]
as    
begin    
	SELECT * FROM  EtechTexasProduct
End 

GO




