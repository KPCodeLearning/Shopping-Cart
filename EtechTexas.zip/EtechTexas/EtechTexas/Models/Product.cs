﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EtechTexas.Models
{
    public class Product
    {
        public string itemName { get; set; }
        public int price { get; set; }
        public string itemImage {get; set;}
    }
}