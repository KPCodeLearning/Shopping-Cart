﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EtechTexas.Models;
namespace EtechTexas.Controllers
{
    public class ProductController : Controller
    {
        string _FileName;
        private SqlConnection con;
        //
        // GET: /Product/

        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult GetData()
        {
            List<Product> employeeList = GetDetails();
            return Json(new { data = employeeList }, JsonRequestBehavior.AllowGet);
        }

        private void connection()
        {
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["connetionStrings"].ConnectionString;
                con = new SqlConnection(constr);
            }
            catch (Exception ex)
            {
                var r = ex.Message;
            }
        }


        
        [HttpPost]
        public ActionResult Create(Product obj )
        {
            try
            {
                if (obj.itemName == null || obj.price == 0)
                {
                    return View();
                }
                HttpFileCollectionBase files = Request.Files;
                HttpPostedFileBase file = files[0];  
                if (file.ContentLength > 0)
                {
                    _FileName = Path.GetFileName(file.FileName);
                    string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                    string extn = Path.GetExtension(_path).ToUpper().ToString();
                    if (extn == ".JPG" || extn == ".JPEG" || extn == ".PNG")
                    {
                        file.SaveAs(_path);
                    }
                    else
                    {
                        ViewData["errorext"] = "Please Uplod file only in JPG, JPEG or PNG";
                        return View();
                    }
                }

                AddDetails(obj);
                GetData();
                return View();
                //return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        private void AddDetails(Product obj)
        {
            connection();
            SqlCommand com = new SqlCommand("AddProduct", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ItemName", obj.itemName);
            com.Parameters.AddWithValue("@Price", obj.price);
            com.Parameters.AddWithValue("@ProductImage",_FileName);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
        }

        private List<Product> GetDetails()
        {
            connection();
            List<Product> lst = new List<Product>();
            SqlCommand com = new SqlCommand("GetProduct", con);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader rdr = com.ExecuteReader();
            while (rdr.Read())
            {
                string path = "\"../../UploadedFiles/" + rdr["productImage"].ToString() + "\"";
                lst.Add(new Product
                {
                    itemName = rdr["itemName"].ToString(),
                    price = Convert.ToInt32(rdr["Price"]),

                    itemImage = "<img src=" + path + " height=\"100\" width=\"100\" />",
                });
            }
            con.Close();
            return lst;
        }

        //
        // GET: /Product/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Product/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Product/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Product/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
